# Weather Trends & Forecast Dashboard

This project collects real-time weather data using Python and visualizes trends using Power BI.

## 🌦 Features

- Tracks temperature, humidity, and weather conditions daily
- Uses OpenWeatherMap API for real-time data
- Visualized using Power BI (CSV format)

## 📂 Files

- `weather_logger.py`: Python script to log weather data
- `weather_data.csv`: Sample dataset for Power BI
- `README.md`: Project overview

## 🔧 Setup Instructions

1. Get your API key from [OpenWeatherMap](https://openweathermap.org/api).
2. Replace `YOUR_API_KEY` in `weather_logger.py`.
3. Run the script daily (or schedule it) to collect data.
4. Load `weather_data.csv` into Power BI to build your dashboard.

## 📊 Suggested Visuals in Power BI

- Line Chart: Temperature over time
- Column Chart: Humidity over time
- Card: Latest Weather Condition
- Slicer: Filter by city (if extended)

Happy coding & visualizing!
