import requests
import pandas as pd
from datetime import datetime

API_KEY = 'YOUR_API_KEY'  # Get from https://openweathermap.org/api
CITY = 'New York'
URL = f"http://api.openweathermap.org/data/2.5/weather?q={CITY}&appid={API_KEY}&units=metric"

def fetch_weather():
    response = requests.get(URL)
    if response.status_code == 200:
        data = response.json()
        weather = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "city": CITY,
            "temperature_C": data["main"]["temp"],
            "humidity_%": data["main"]["humidity"],
            "condition": data["weather"][0]["main"]
        }
        return weather
    else:
        print("Error:", response.status_code)
        return None

weather = fetch_weather()
if weather:
    df = pd.DataFrame([weather])
    df.to_csv("weather_data.csv", mode='a', header=not pd.io.common.file_exists("weather_data.csv"), index=False)
    print("Weather data saved.")
